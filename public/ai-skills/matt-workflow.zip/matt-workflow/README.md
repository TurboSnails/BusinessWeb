# Matt Pocock 开发工作流 Skills（v1.3 中文版）

```text
grill-me ─ to-spec ─ to-tickets ─┬─ implement ──────┬─ code-review ─ pr ─ retro
                                 └─ implement-spec ─┘
```

从想法到合并的完整开发流程：先被追问把设计想清楚，写成 spec，拆成带依赖关系的 tickets，逐个或并行实现，双轴代码审查，写 PR，最后复盘改进 agent 环境。

## 包含

| Skill | 作用 |
| --- | --- |
| `matt-workflow` | 总览与导航：判断当前在哪一站、下一步用哪个 skill |
| `grill-me` | 围绕计划或设计持续追问（调用 `grilling`） |
| `to-spec` | 把对话综合成 spec（PRD）并发布到 issue tracker |
| `to-tickets` | 把 spec 拆成 tracer-bullet tickets，带 blocking edges |
| `implement` | 一次实现一个 ticket，用 `tdd`，完成后 `code-review` |
| `implement-spec` | v1.3 新增：整份 spec 并行实现到 integration branch |
| `code-review` | Standards / Spec 双轴审查 |
| `pr` | v1.3 新增：PR body 模板（图示、证据、合并风险） |
| `retro` | v1.3 新增：复盘 session，改进 agent 环境 |
| `grilling` · `tdd` · `setup-matt-pocock-skills` | 上面各站依赖的辅助 skill |

## 安装

1. 解压，把 `skills/` 下的全部文件夹复制到项目的 `.claude/skills/`（Claude Code）或 `.agents/skills/`（Codex 等）。
2. 重新打开会话，先运行 `/setup-matt-pocock-skills` 配置 issue tracker（GitHub / GitLab / 本地文件）和 triage labels。
3. 运行 `/matt-workflow` 查看流程，或直接从 `/grill-me` 开始。

各站都是手动调用的 slash command，不会自动连跑；`implement-spec` 需要支持子代理和 git worktree 的助手。

## 来源与许可

翻译自 [mattpocock/skills](https://github.com/mattpocock/skills)（MIT，见 `LICENSE`）。`pr` 的图示菜单来自 Dex Horthy 的 `show-me`，署名见 `skills/pr/CREDITS.md`。
