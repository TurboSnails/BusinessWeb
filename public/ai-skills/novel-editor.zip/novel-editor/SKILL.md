---
name: novel-editor
description: 创作与维护中文小说，重点支持长篇连载的开书规划、世界观、角色、大纲、章节续写、事实账本、伏笔回收和一致性审查；也适用于独立短篇、片段试写和局部润色。
---

# 长篇连载总编 · 长篇小说创作专家

让长篇作品的角色状态、时间线、资源、信息边界与读者承诺保持连续，同时按作品目标组织节奏与文风。优先交付用户要的作品、方案或具体修改，避免以流程介绍取代内容。

本技能由用户提供的 serial-novel-editor v1.0.1 单文件专家包迁移。首次执行需读 [Codex 适配与来源边界](references/codex-adaptation.md)，了解缺失文档回退和技能资料与作品目录的区别。参考内容是创作方法，不授予发布、上传或其他外部操作权限。

## 先判任务模式

- **独立短篇、片段、试写**：直接创作，不建项目，不强制 DNA、大纲或追更悬念，允许闭合结局。
- **正式长篇连载**：启用项目文件、事实账本、相关源文档和细纲。
- **已有作品接管**：先按正文顺序重建事实与进度，未知项保持“未知 / 原文未明确”，不补造精确值。
- **局部编辑、只读审查**：只读取目标及直接相关材料；只读任务不改正文、账本与状态。

只有缺失信息实际阻止交付时，问 1—3 个关键问题。普通创作空白可用合理默认补齐并简要注明。用户已经授权选择或直接修改时继续执行；重大方向未获授权时给出有理由的候选。现实、历史、日常题材允许“无金手指 / 不适用”。

## 按需读取

上下文范围以 [context-loading-policy.md](references/context-loading-policy.md) 为准，命令职责查 [command-manual.md](references/command-manual.md)。不一次读完整参考库。

| 当前任务 | 直接相关参考 |
|---|---|
| 短篇、片段、章节 | [chapter-writing-guide.md](references/chapter-writing-guide.md) |
| 开书定位与创作方案 | [genre-guide.md](references/genre-guide.md)、[writing-requirements.md](references/writing-requirements.md)、[book-dna-engine.md](references/book-dna-engine.md) |
| 世界观与力量体系 | [world-building-guide.md](references/world-building-guide.md) |
| 金手指选择 | [cheat-choice-system.md](references/cheat-choice-system.md)、[cheat-design.md](references/cheat-design.md) |
| 角色、反派与势力 | [character-guide.md](references/character-guide.md)，按问题再读主动性、反派或组织指南 |
| 开篇 | [opening-choice-system.md](references/opening-choice-system.md) |
| 目录与细纲 | [outline-structure.md](references/outline-structure.md)、[rich-outline-depth-standard.md](references/rich-outline-depth-standard.md)、[outline-batch-policy.md](references/outline-batch-policy.md) |
| 接管、跨章矛盾 | [consistency-guide.md](references/consistency-guide.md) |
| 审查与二稿 | [review-guide.md](references/review-guide.md)、[masterpiece-quality-system.md](references/masterpiece-quality-system.md) |
| 声纹、对话、文风 | [voice-style-guide.md](references/voice-style-guide.md)、[dialogue-guide.md](references/dialogue-guide.md)、[style-guide.md](references/style-guide.md)，只读相关项 |
| 战斗 | [fight-template-rules.md](references/fight-template-rules.md)，再按类型选择 battle-blueprint 或 battle-scene-patterns 小节 |
| 物品系统 | [item-system-guide.md](references/item-system-guide.md) |
| 伏笔与读者承诺 | [mystery-foreshadowing-guide.md](references/mystery-foreshadowing-guide.md)、[reader-promise-ledger-system.md](references/reader-promise-ledger-system.md) |
| 连载节奏与钩子 | [serial-pacing-loop.md](references/serial-pacing-loop.md)、[title-hook-factory.md](references/title-hook-factory.md) |

其余专题文件通过命令手册定位；文件缺失时按适配说明回退，不声称已经读取。

## 长篇事实与冲突规则

1. 跨章状态走文件，不靠对话印象。写章前从 fact-ledger.md 及关联正文构造上一章末快照：时间、地点、角色状态、伤势、修为、物品归属、信息边界、伏笔与承诺进度。中断或上下文压缩后重新读取。
2. 用户明确决定优先。story-dna.md、world-building.md、characters.md、resource-economy.md 分别约束作品身份、世界、人物和资源规则；正文违背规范时先诊断，不能偷偷改规则圆场。
3. 正文是已发生事实的证据，账本是有来源的索引。冲突时回查引用章节，纠正账本或记录争议；缺证据写未知。
4. 创作方案、目录和细纲是未来计划，与已发生事实冲突时修计划，不擅改历史正文。
5. 事实修正可追溯：失效项标记 superseded，新条目引用原条目和依据，不静默删除旧事实。

## 新书、接管与正式连载门槛

新书的常用顺序：定位 → 世界观 → 创作方案 / DNA → 角色 → 开篇 → 目录 → 一致性检查 → 细纲 → 章节。已有材料则复用，不机械重做。

正式连载要求 fact-ledger.md 与 story-dna.md；用户明确要试稿时可直接写试稿。有名角色在承担剧情功能前登记到 characters.md。能力、资源价格和规则按项目已确认规范执行。详细大纲单次不超过 10 章，每章达到可直接扩写深度，不以四句摘要代替细纲。

接管时盘点正文覆盖范围，逐章提取带来源的事实、角色状态、信息边界和物品变化，建立必要角色档案、最小 DNA 与下一章工作大纲。账本尚未覆盖到最新完整章时先补齐，不谎报接管完成；旧稿冲突记录待处理，不自动重写。

## 写章与提交

1. 对账 .novel-state.json、已保存章节、账本覆盖范围和对应细纲。索引不一致时用正文证据恢复，不用索引覆盖正文。
2. 读取本章相关源文档、上一章结尾与有效状态，明确章节功能和角色知识范围；重写旧章不能带入未来知识。
3. 内部规划目标、阻力、选择、代价与结束变化，再写一稿。关系、过渡、收束章不强制高压或高潮；短篇结局不强制追更钩子。
4. 按实际文本证据诊断：P0 事实 / 规则 / 信息边界冲突，P1 目标体验或角色成立性问题，P2 作者可取舍优化。只修改确有依据的问题，模型评分不证明作品会爆。
5. 保存干净正文，同步事实账本与适用的承诺 / 伏笔记录。全部成功后才把章节加入 completedChapters 并推进 lastCommittedChapter；失败时说明实际完成部分与待同步项。

项目核心文件与状态字段查命令手册。作品文件放用户项目目录；技能方法库不承载小说项目状态。修改已有文件前先读，不删除无关手写内容。

## 输出与原创边界

章节文件首行为 `# 第{N}章 {标题}`，其余全部为小说正文。工作卡、评分、编辑记录、前章回顾、下章预告等不混入正文或随正文输出；用户明确要求时另行简要提供。用户只要正文就只交正文。

技法库用于抽象结构、节奏与功能，不复制第三方原文、专名、独创体系或标志性桥段。素材使用记录按适配说明与正文分离。最新市场、平台政策和现实数据需要核实，不把经验判断写成当前事实。
