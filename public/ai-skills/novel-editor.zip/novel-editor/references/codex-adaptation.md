# Codex 迁移与缺失资料处理

## 来源与完整性
来源：用户提供的《长篇连载总编 · 可迁移专家包（单文件版）》，标注 serial-novel-editor v1.0.1。分享链接：https://www.workbuddy.cn/space/d/zTZ7zKccb53MCPrcJUZvtv
按源文件标记恢复 66 个参考文档区块。原文声称 73 份，当前附件没有完整包含，最后的 viral-quality-guide.md 在“五项诊断维度”处截断。不要宣称完整迁移 73 份，也不要将补充规则冒充原包内容。

当前未提供的参考文件：
- chapter-rewrite-pipeline.md
- commands-advanced.md
- commands-core.md
- commands-review.md
- compliance-checklist.md
- market-analysis.md
- overseas-guide.md

## 路径与范围
技能自身的 references/ 是只读方法库；小说项目中的 references/ 是用户素材与拆书记录目录。读方法时解析为本技能目录，写作品时解析为用户指定项目根目录，不往技能安装目录写小说或账本。
用户未指定项目目录时，使用当前工作区的 outputs/ 下有辨识度的作品目录；已有项目则沿用其目录。只读审查、一次性片段默认在对话交付，不建立项目。
原文提到的 novel-writer 指本技能 novel-editor，无需另行安装同名技能。自然语言请求与斜杠命令同样可用。

## 缺失文件的执行回退
- commands-core/review/advanced：用 command-manual.md 的命令职责和输出约定，并读取对应已存在的专题指南。不得编造缺失命令参数。/导出 按章号排序汇集已保存章节到 export/{书名}-完整小说.md，检查缺章和重复章，不修改原章。
- chapter-rewrite-pipeline：按本技能“写章与提交”流程执行证据式二稿，辅以 chapter-writing-guide.md、masterpiece-quality-system.md 和 consistency-guide.md。没有实际问题时不强制重写。
- market-analysis：按用户题材、读者与目标平台分析定位、差异和风险。涉及当前排行榜、平台政策或市场数据时联网核实并记录日期；无法核实则明确是经验判断，不伪造数据。
- compliance-checklist/overseas-guide：不宣称完成这些原包专项审查；按用户明确指定的平台、地区、目标语言和任务范围做基础检查。当前规则以官方来源核实，法律结论需注明依据与不确定性。需要原包专门方法时说明文件未提供。
- viral-quality-guide：只应用已保存的目标读者与证据标准，辅以 reader-retention-guide.md 和 masterpiece-quality-system.md；不补造缺失的五维表格或预测真实追读率。

## 交付冲突
正文纯净要求优先。方法使用记录、版权说明与审查摘要放在独立编辑记录或用户明确要求的单独说明中；不得附在章节正文文件内。用户只要正文时不额外输出这些内容。
所有项目状态仅在实际文件写入成功后报告。需要查看项目时先读现有文件，不能宣称记住了未读取的旧章。
