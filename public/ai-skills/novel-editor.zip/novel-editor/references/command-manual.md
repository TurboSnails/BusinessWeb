命令手册（命令总表与解析规则）
命令手册拆分文档
作用
本文件用于承接 SKILL.md 中过长的命令说明，作为命令职责、前置条件、输出文件和参考资料加载规则的集中索引。
更细的执行规范已拆分到：
- commands-core.md：核心创作流程命令。
- commands-review.md：审查、修复、事实追踪与合规命令。
- commands-advanced.md：详细大纲、战役蓝图、追读增强、场景与组织系统等高级命令。
- long-novel-command-manual.md：长篇小说从开书、前30章、分卷、10章循环到日更复盘的完整使用手册。
- item-system-guide.md：原创物品动态生长、物品库参考和版权边界。
- fight-template-rules.md：模式库匹配、叙事阶段和参考资料版权声明。
- book-dna-engine.md、protagonist-agency-engine.md、antagonist-pressure-engine.md：书级吸引力、主角主动性和反派压迫感。
- reader-promise-ledger-system.md、serial-pacing-loop.md、title-hook-factory.md：连载承诺、节奏循环、标题与钩子。
- context-loading-policy.md、sample-chapter-calibration.md、toxic-reader-simulation.md：上下文控制、样章校准和读者弃书点模拟。
- opening-choice-system.md：开篇需求画像、候选过滤、后续承接测试、拒绝记忆、偏好重置和最终固化。
- cheat-choice-system.md：金手指需求画像、候选过滤、剧情压力测试、拒绝记忆、定向重做和最终固化。
- punctuation-style-guide.md、outline-batch-policy.md、rich-outline-depth-standard.md：标点/破折号控制、10 章详细大纲批次规则和细纲深度标准。
全局命令规则
- 命令执行前必须确认前置条件。
- 写文件前必须检查目标文件是否存在；存在时先读取原文件。
- 增量更新时不得删除用户未要求删除的手写内容。
- 用户已经明确要求修改或授权直接处理时，可以在评估影响后继续，不重复索要确认。
- 不留下无用途的备份或版本交付物；允许使用工具内部临时写入、原子替换或现有版本控制恢复，失败时不得推进完成状态。
- 输出路径必须使用统一目录：outlines/、chapters/、references/、export/。
- 任何命令不得创建超出命令定义范围的新文件。
- 只读审查、查看状态和给建议不更新正文、账本或 .novel-state.json。
命令分类
初始化与规划
命令
输出
主要参考
/市场分析
市场分析报告
market-analysis.md
/开始
.novel-state.json、fact-ledger.md
genre-guide.md, market-analysis.md
/世界观
world-building.md
world-building-guide.md
/金手指方案
cheat-options.md
cheat-choice-system.md, cheat-design.md
/作品基因
story-dna.md
masterpiece-patterns.md, book-dna-engine.md
/创作方案
creative-plan.md、story-dna.md、reader-promise-ledger.md
outline-structure.md, writing-requirements.md, book-dna-engine.md, reader-promise-ledger-system.md
/文风设定
voice-style-cards.md
style-guide.md, voice-style-guide.md
/卷规划
volume-plan.md
volume-structure-guide.md
/长线伏笔
foreshadowing-ledger.md
mystery-foreshadowing-guide.md, reader-promise-ledger-system.md
/名场面规划
iconic-scenes.md
iconic-scenes-guide.md, masterpiece-patterns.md
/开篇方案
opening-options.md
opening-choice-system.md, opening-30-chapters-system.md, hook-design.md, reader-retention-guide.md
角色与组织
命令
输出
主要参考
/角色开发
characters.md
character-guide.md
/角色弧线
character-arcs.md
character-arc.md
/支线
subplot-outline.md
subplot-planning.md
/主角引擎
protagonist-engine.md
protagonist-engine-guide.md, protagonist-agency-engine.md
/反派阶梯
villain-ladder.md
villain-ladder-guide.md, antagonist-pressure-engine.md
/势力开发
faction-network.md、social-system.md
faction-social-guide.md
/家族开发
clan-ledger.md、lineage-tree.md
clan-lineage-guide.md
大纲与章节
命令
输出
主要参考
/目录
chapter-directory.md
outline-structure.md, cheat-choice-system.md, opening-choice-system.md, serial-pacing-loop.md, title-hook-factory.md
/大纲扩充
outlines/outline-{start}-{end}.md
outline-structure.md, outline-batch-policy.md, rich-outline-depth-standard.md, cheat-choice-system.md, pacing-guide.md, serial-pacing-loop.md, title-hook-factory.md
/大纲审查
大纲问题清单
review-guide.md, consistency-guide.md, rich-outline-depth-standard.md
/大纲修订
更新 outlines/outline-{start}-{end}.md
consistency-guide.md, rich-outline-depth-standard.md
/战役蓝图
outlines/outline-{start}-{end}.md（插入战役总纲）
pacing-guide.md, scene-patterns-guide.md
/章节
干净正文；正式长篇另更新事实与适用账本
context-loading-policy.md, chapter-writing-guide.md；其他专项按触发条件读取
/续写
下一章二稿正文与状态更新
chapter-writing-guide.md, context-loading-policy.md, chapter-rewrite-pipeline.md, consistency-guide.md
/接管旧稿
从已有正文重建必要账本、项目基线和进度索引
context-loading-policy.md, consistency-guide.md
/批量生成
chapters/ch{NNN}.md、chapters/batch-{start}-{end}.md、fact-ledger.md
chapter-writing-guide.md, chapter-rewrite-pipeline.md, consistency-guide.md
/润色
更新章节正文
style-guide.md, voice-style-guide.md, anti-flat-writing-guide.md
/重写
更新章节正文
chapter-writing-guide.md, consistency-guide.md
/读者期待
读者期待与承诺状态
reader-promise-ledger-system.md, title-hook-factory.md
/前30章打磨
前30章留存问题清单与修订建议
opening-30-chapters-system.md, reader-retention-guide.md
/战役蓝图 触发时机：🔄 完全自动触发，用户无需手动调用。当 /大纲扩充 扫描 chapter-directory.md 检测到连续3章以上为🗡️战斗章（同一对抗对象或同一核心冲突）时，AI自动在段弧线规划后嵌入战役总纲，然后按总纲分章功能分配逐章扩充。/章节、/批量生成、/续写 写章前自动检测 outline 中是否存在战役总纲，存在则自动切换为弹性模式（起章承章不强制高潮）。手动调用 /战役蓝图 仅用于：重新规划战斗结构、修正自动生成的总纲、为未识别的跨章事件补充总纲。
名作拆书与 AI 自动创作工具
命令
输出
主要参考
/拆书
references/masterpiece-abstraction.md 或指定拆书记录
masterpiece-patterns.md, references/masterpiece-abstraction.md
/技法应用
notes/第{start}-{end}章名作技法应用清单.md
references/masterpiece-abstraction.md, outlines/outline-{range}.md
/大纲技法审查
大纲问题清单；必要时更新对应 outlines/outline-{range}.md
notes/第{start}-{end}章名作技法应用清单.md, consistency-guide.md
/章节技法审查
章节问题清单；必要时更新对应 chapters/ch{NNN}.md
chapter-writing-guide.md, review-guide.md
/一键打磨
技法应用清单、逻辑问题清单、修改摘要、更新后的目标文件
references/masterpiece-abstraction.md, review-guide.md, consistency-guide.md
/拆书
用户只需提供作品名、文件范围或学习目标。AI 依据用户自备的参考素材或用户指定文本，只抽取结构、节奏、压力来源、爽点机制、伏笔回收和章末钩子。
执行规则：
- 只提炼技法，不复制原文句子、设定名、角色名、桥段。
- 输出必须转成本书可用的抽象方法。
- 每条拆书结果必须写明“本书可用位置”和“禁止照搬点”。
- 如果用户没有指定作品，优先从 references/masterpiece-abstraction.md 已登记的样本分工中选择。
/技法应用
用户只需输入章节范围，例如 /技法应用 17-30。AI 必须读取：
- references/masterpiece-abstraction.md
- 对应 outlines/outline-{range}.md
- chapter-directory.md
- 必要时读取 world-building.md、characters.md、fact-ledger.md
输出要求：
- 为每章生成“核心借鉴、章节重点、爽点设计、风险点、检查项”。
- 所有建议必须落到本书已有主线、角色、资源和伏笔。
- 不允许只给泛泛理论。
- 若目标应用清单已存在，必须增量更新，不得覆盖用户已确认内容。
/大纲技法审查
用户只需输入章节范围或目标大纲文件。AI 必须对照技法应用清单审查大纲是否达标。
审查维度：
- 章节功能是否明确。
- 表层压力和深层压力是否同时存在。
- 爽点是否来自准备、判断、规则或代价，而不是无脑碾压。
- 伏笔是否有回收计划。
- 章末钩子是否推动下一章。
- 是否违反 world-building.md、characters.md、fact-ledger.md。
执行方式：
- 若用户说“只审查”，只输出问题清单和建议。
- 若用户说“直接修”，在读取目标文件后按最小改动原则更新大纲。
- 修改后必须列出改动摘要和仍需用户审核的问题。
/章节技法审查
用户只需输入章节号。AI 必须读取对应正文、详细大纲、技法应用清单和事实账本。
输出分三类：
- 必须修：事实矛盾、设定冲突、角色失真、承诺落空。
- 建议修：节奏弱、爽点不明显、钩子不够强、信息重复。
- 可保留：符合本书底色但仍可打磨的内容。
如果用户要求自动修改，AI 只修改对应章节正文，不得擅自改源设定。
/一键打磨
用户只需输入范围，例如 /一键打磨 17-30。AI 依次执行：
1. 检查章节目录、详细大纲、事实账本是否存在。
2. 读取 masterpiece-patterns.md 与 references/masterpiece-abstraction.md（名作拆书技法与抽象登记表）。
3. 对目标章节进行技法应用审查。
4. 对目标章节进行一致性检查。
5. 生成修改方案。
6. 用户允许“直接修”时，更新目标文件。
7. 输出最终审核清单，让用户只阅读结果是否符合要求。
默认规则：
- 未经用户明确要求，不批量改正文。
- 可自动修正明显数字、章节标题、摘要不一致等低风险问题。
- 涉及主线、角色命运、世界规则的大改必须先列出方案。
审查与修复
命令
输出
主要参考
/自检
章节自检报告
review-guide.md
/格式检查
格式检查报告
review-guide.md
/一致性检查
一致性报告
consistency-guide.md
/逻辑审查
逻辑审查报告
writing-requirements.md
/节奏诊断
连续章节节奏诊断
serial-pacing-loop.md, pacing-guide.md
/追读诊断
追读理由与弃书风险诊断
reader-retention-guide.md, reader-promise-ledger-system.md
/矛盾修复
章节修复与事实账本追加记录
consistency-guide.md
导出
命令
输出
主要参考
/导出
export/{书名}-完整小说.md
commands-advanced.md
状态文件更新
只有改变项目产物的生成和修订命令才同步 .novel-state.json。一章必须在正文和账本均成功写入后才能推进 lastCommittedChapter：
{
  "schemaVersion": 2,
  "currentStage": "chapter_writing",
  "lastCommittedChapter": 12,
  "activeChapter": null,
  "lastReviewedChapter": null,
  "completedChapters": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
  "factLedgerCoveredThrough": 12,
  "latestOutlineFile": "outlines/outline-011-020.md",
  "outlineFiles": ["outlines/outline-001-010.md", "outlines/outline-011-020.md"],
  "lastFactUpdate": "ch012",
  "pendingIssues": []
}
