上下文加载策略（写章前读什么、读多少）
上下文加载策略
作用
本文件是“当前任务需要读取什么”的唯一权威源。其他指南可以说明自身用途，但不得另列一套强制加载清单；若与本文件冲突，以根目录 SKILL.md 的任务模式和本文件为准。
通用原则
- 先判断任务模式和交付范围，再读取目标文本、必要项目事实与直接相关指南。
- 文件存在不等于必须读取。先定位目标章、相关角色、活跃伏笔和本次会用到的规则。
- 用户明确要求只读、直接给正文、不建项目或自行决定时，尊重该范围。
- references/ 下的模式库只在确实影响本次结果时读取；先选一个最匹配的小节，不预载完整模式库。
- 最新市场、平台规则或现实数据必须联网核实并注明日期；无法核实时标为经验判断。
按任务模式加载
独立短篇或片段
必读仅为用户给出的素材和 chapter-writing-guide.md。按实际问题选择一个或数个专项文件，例如对话读 dialogue-guide.md，风格读 style-guide.md，悬疑读相应题材指南。
不要求 .novel-state.json、事实账本、DNA、目录、详细大纲、开篇选择、金手指选择或追更报告。完整故事允许闭合结尾。
局部编辑或只读审查
读取目标文本和直接相关指南。跨章事实审查才读取相关章节、fact-ledger.md 与 consistency-guide.md；只查对话、标点或文风时不加载爆款、追读、战斗或整书一致性指南。
只读任务不修改正文、账本或状态。
正式长篇写章或续写
按下面顺序建立最小写作上下文：
1. 对账 .novel-state.json、目标章节文件、fact-ledger.md 覆盖范围和对应细纲。
2. 读取 story-dna.md；再读取与本章相关的 world-building.md、characters.md、resource-economy.md 条目。
3. 从 fact-ledger.md 构造上一章末的当前有效状态；读取上一章结尾及目标章详细大纲。
4. 若大纲信息不足，再读 creative-plan.md、chapter-directory.md 的相关范围。
5. 读取 chapter-writing-guide.md。需要默认二稿时读 chapter-rewrite-pipeline.md；存在用户确认样章时优先读 sample-chapter-calibration.md。
6. 仅按触发条件读取专项文件。
专项触发条件：
条件
读取
第 1 章或用户要求重选开篇
opening-choice-system.md
前 30 章留存诊断
opening-30-chapters-system.md
本章实际使用金手指
cheat-choice-system.md
战斗场景确需模板
fight-template-rules.md，再从 references/battle-scene-patterns.md 选一个最匹配的模板；不适配时跳过
连续生成或节奏诊断
serial-pacing-loop.md
对话是本章重点或出现问题
dialogue-guide.md
本章引入或转移关键物品
item-system-guide.md
主角被动、反派压力或场景压力出现问题
对应的主动性、反派或压力指南
文风或标点出现明确问题
voice-style-guide.md、style-guide.md、anti-flat-writing-guide.md 或 punctuation-style-guide.md 中直接相关的一份
已有作品接管
1. 盘点已有章节和项目文件，确定正文覆盖范围。
2. 按章节顺序提取正文明确支持的事实；记录来源章节、证据和有效范围，未知内容保持未知。
3. 建立或补齐 fact-ledger.md、必要角色档案、最小 DNA 和下一章工作大纲。
4. 将 factLedgerCoveredThrough 设为已完整提取的最后一章；未覆盖到最新正文时不得进入正式续写。
5. 对账后再使用正式长篇写章流程。
提交与恢复
一章只有在正文、事实账本和需要维护的承诺记录都写入成功后，才能加入 completedChapters 并推进 lastCommittedChapter。activeChapter 只表示正在处理的目标，审查旧章不得改变连载末章。
续写前若状态索引、文件和账本不一致，以已保存正文为证据重建索引，并把未完成的账本同步列为待处理问题。不要凭状态文件覆盖正文。
禁止
- 不要每章默认读取全部 references 或全部增强文件。
- 不要读取完整原著文本来写正文。
- 不要让素材库覆盖用户要求、正文事实和项目源文档。
- 不要把后期事实或角色知识带入历史章节的重写上下文。
